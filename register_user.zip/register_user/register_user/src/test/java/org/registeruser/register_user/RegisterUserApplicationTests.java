package org.registeruser.register_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
