package org.registeruser.register_user.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="dept")
public class Department {

	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "DEPT_SEQ")
    @SequenceGenerator(name = "dept_seq", sequenceName = "DEPT_SEQ")
	private int id;
    
	@NotNull
	 @Column(name="department_name", unique=true)
	private String  departmentName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
}
