package org.registeruser.register_user.service;

import java.util.List;

import org.registeruser.register_user.model.Login;
import org.registeruser.register_user.model.User;
import org.registeruser.register_user.repo.LoginRepo;
import org.registeruser.register_user.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {
	@Autowired
	private UserRepo repo;
	public User saveUser(User user) {
		return repo.save(user);
	}
	public List<User> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> fetchAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	public User fetchUserById(int id) {
		// TODO Auto-generated method stub
		return repo.findUserById(id);
	}
	
	
	
	@Autowired
	private LoginRepo rep;
	public Login fetchLoginByUserName(String userName) {
		return rep.findByUserName(userName);
		// TODO Auto-generated method stub
	}
	public Login saveLogin(Login login) {
		// TODO Auto-generated method stub
		return rep.save(login);
	}
	
	}
	
