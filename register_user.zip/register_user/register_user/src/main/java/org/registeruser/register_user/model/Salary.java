package org.registeruser.register_user.model;


	import java.util.Date;

	import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.ManyToMany;
	import javax.persistence.OneToOne;
	import javax.persistence.SequenceGenerator;
	import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
	import lombok.Data;
	import lombok.NoArgsConstructor;

		@AllArgsConstructor
		@NoArgsConstructor
		@Data
		@Entity
		@Table(name="salary")
		public class Salary {
			@Id
		    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "SAL_SEQ")
		    @SequenceGenerator(name = "sal_seq", sequenceName = "SAL_SEQ")
			private int id;
			
			@NotNull
			@Column(name="employeeName",unique=true)
			private String  employeeName;
			
			@NotNull
			@Column(name="gradeName")
			private String gradeName;
			
			@NotNull
			@Column(name="netSalary")
			private int  netSalary;
			
			@NotNull
			@Column(name="salaryMonth")
			private String  salaryMonth;
			
			@NotNull
			@Column(name="departmentName")
			private String departmentName;
			
			@NotNull
			@Column(name="basicSalary")
			private int  basicSalary;
			
			@NotNull
			@Column(name="medicalAllowance")
			private int  medicalAllowance;
			
			public String getSalaryMonth() {
				return salaryMonth;
			}
			public void setSalaryMonth(String salaryMonth) {
				this.salaryMonth = salaryMonth;
			}
			public int getNetSalary() {
				return netSalary;
			}
			public void setNetSalary(int netSalary) {
				this.netSalary = netSalary;
			}
			public int getBasicSalary() {
				return basicSalary;
			}
			public void setBasicSalary(int basicSalary) {
				this.basicSalary = basicSalary;
			}
			public int getMedicalAllowance() {
				return medicalAllowance;
			}
			public void setMedicalAllowance(int medicalAllowance) {
				this.medicalAllowance = medicalAllowance;
			}
			public String getEmployeeName() {
				return employeeName;
			}
			public void setEmployeeName(String employeeName) {
				this.employeeName = employeeName;
			}
			public int getId() {
				return id;
			}
			public void setId(int id) {
				this.id = id;
			}
			
			public String getGradeName() {
				return gradeName;
			}
			public void setGradeName(String gradeName) {
				this.gradeName = gradeName;
			}
			
			
			
			public String getDepartmentName() {
				return departmentName;
			}
			public void setDepartmentName(String departmentName) {
				this.departmentName = departmentName;
			}
			
			
			
		}
