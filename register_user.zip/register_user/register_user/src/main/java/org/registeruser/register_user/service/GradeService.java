package org.registeruser.register_user.service;


	import java.util.List;

import org.registeruser.register_user.model.Grade;
	
	import org.registeruser.register_user.repo.GradeRepo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	@Service
	public class GradeService {
		@Autowired
		private GradeRepo repo;
		public Grade saveGrade(Grade grade) {
			return repo.save(grade);
		}
		public List<Grade> fetchAll() {
			// TODO Auto-generated method stub
			return repo.findAll();
		}
		public Grade fetchGradeById(int id) {
			// TODO Auto-generated method stub
		return repo.findGradeById(id);
		}
	}