package org.registeruser.register_user.service;


import java.util.List;

import org.registeruser.register_user.model.Department;
	
	import org.registeruser.register_user.repo.DepartmentRepo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	@Service
	public class DepartmentService {
		@Autowired
		private DepartmentRepo repo;
		public Department saveDepartment(Department dept) {
			return repo.save(dept);
		}
		public List<Department> fetchAll() {
			// TODO Auto-generated method stub
			return repo.findAll();
		}
		public Department fetchDepartmentById(int id) {
			// TODO Auto-generated method stub
			return repo.findDepartmentById(id);
		}
}
