package org.registeruser.register_user.repo;

import org.registeruser.register_user.model.Login;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginRepo extends JpaRepository<Login, String> {

	Login findByUserName(String userName);

}
