package org.registeruser.register_user.model;


	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.SequenceGenerator;
	import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
	import lombok.Data;
	import lombok.NoArgsConstructor;

	@AllArgsConstructor
	@NoArgsConstructor
	@Data
	@Entity
	@Table(name="grade")
	public class Grade {
		@Id
	    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "GRADE_SEQ")
	    @SequenceGenerator(name = "grade_seq", sequenceName = "GRADE_SEQ")
		private int 	id;
	    
		@NotNull
		@Column(name="employeeName",unique=true)
		private String employeeName;
		
		@NotNull
		 @Column(name="grade_name")
		private String  gradeName;
		 
		@NotNull
		 @Column(name="basic")
		private int  basic;
		 
		@NotNull
		 @Column(name="travel_allowance")
		private int  travelAllowance;
		 
		@NotNull
		 @Column(name="medical_allowance")
		private int  medicalAllowance;
		 
		@NotNull
		 @Column(name="provident_fund")
		private int  providentFund;
		 
		@NotNull
		 @Column(name="bonus")
		private int  bonus;
		
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public int getBasic() {
			return basic;
		}
		public void setBasic(int basic) {
			this.basic = basic;
		}
		public int getTravelAllowance() {
			return travelAllowance;
		}
		public void setTravelAllowance(int travelAllowance) {
			this.travelAllowance = travelAllowance;
		}
		public int getMedicalAllowance() {
			return medicalAllowance;
		}
		public void setMedicalAllowance(int medicalAllowance) {
			this.medicalAllowance = medicalAllowance;
		}
		public int getProvidentFund() {
			return providentFund;
		}
		public void setProvidentFund(int providentFund) {
			this.providentFund = providentFund;
		}
		public int getBonus() {
			return bonus;
		}
		public void setBonus(int bonus) {
			this.bonus = bonus;
		}
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getGradeName() {
			return gradeName;
		}
		public void setGradeName(String gradeName) {
			this.gradeName = gradeName;
		}
		
}
