package org.registeruser.register_user.service;

import java.util.List;

import org.registeruser.register_user.model.Salary;
import org.registeruser.register_user.repo.SalaryRepo;
import org.registeruser.register_user.model.Salary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


	@Service
	public class SalaryService {
		@Autowired
		private SalaryRepo repo;
		public Salary saveSalary(Salary salary) {
			return repo.save(salary);
		}
		public List<Salary> fetchAll() {
			// TODO Auto-generated method stub
			return repo.findAll();
		}
		public Salary fetchSalaryById(int id) {
			// TODO Auto-generated method stub
			return repo.getSalaryById(id);
		}
		
	


	}
