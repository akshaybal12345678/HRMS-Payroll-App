package org.registeruser.register_user.repo;

import org.registeruser.register_user.model.Login;
import org.registeruser.register_user.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface UserRepo extends JpaRepository<User, String>{

	User findByEmployeeName(String employeeName);

	User findUserById(int id);

}