package org.registeruser.register_user.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.registeruser.register_user.model.*;
import org.registeruser.register_user.repo.DepartmentRepo;
import org.registeruser.register_user.repo.GradeRepo;
import org.registeruser.register_user.repo.SalaryRepo;
import org.registeruser.register_user.repo.UserRepo;
import org.registeruser.register_user.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins= "*",allowedHeaders="*")
public class UserController {

	@Autowired
	private GradeRepo repo3;
	
	@Autowired
	private SalaryRepo repo2;
	
	@Autowired
	private DepartmentRepo repo1;
	
	@Autowired
	private UserRepo repo;
		
	@Autowired
	private RegistrationService userService;
	
	@Autowired
	private SalaryService salaryService;
	
	@Autowired
	private GradeService gradeService;
	
	@Autowired
	private DepartmentService deptService;
	
	@RequestMapping(path= "/user",method=RequestMethod.POST)
	@ResponseStatus(value=HttpStatus.OK)
	
	public ResponseEntity <User> registerUser(@RequestBody User user) {
		User userObj=null;
		userObj=userService.saveUser(user);
		return ResponseEntity.ok(userObj);
				
	}
	
	@RequestMapping(path= "/sal",method=RequestMethod.POST)
	@ResponseStatus(value=HttpStatus.OK)
	
	public ResponseEntity <Salary> salaryDetails(@RequestBody Salary salary) {
		Salary salaryObj=null;
		salaryObj=salaryService.saveSalary(salary);
		
		return ResponseEntity.ok(salaryObj);}
	

@RequestMapping(path= "/grade",method=RequestMethod.POST)
@ResponseStatus(value=HttpStatus.OK)

public ResponseEntity <Grade> gradeDetails(@RequestBody Grade grade) {
	Grade gradeObj=null;
	System.out.println(grade);
	gradeObj=gradeService.saveGrade(grade);
	System.out.println(gradeObj);
	return ResponseEntity.ok(gradeObj);
}


@RequestMapping(path= "/dept",method=RequestMethod.POST)
@ResponseStatus(value=HttpStatus.OK)

public ResponseEntity <Department> departmentDetails(@RequestBody Department dept) {
	Department deptObj=null;
	System.out.println("hello");
	deptObj=deptService.saveDepartment(dept);
	return ResponseEntity.ok(deptObj);}

@RequestMapping(path= "/admin",method=RequestMethod.POST)
@ResponseStatus(value=HttpStatus.OK)

public ResponseEntity <Login> loginDetails(@RequestBody Login login) {
	Login loginObj=null;
	System.out.println(login);
	loginObj=userService.saveLogin(login);
	System.out.println(loginObj);
	return ResponseEntity.ok(loginObj);
}

@GetMapping("/vuuemp12")
	public List<User> getAllEmployees(){
		List<User> list = userService.fetchAll();
		return list;
	}

@GetMapping("/vuudep34")
public List<Department> getAllDepartments(){
	return deptService.fetchAll();
}
@GetMapping("/vuusal21")
public List<Salary> getAllSalary(){
	return salaryService.fetchAll();
}
@GetMapping("/vuugrad21")
public List<Grade> getAllGrade(){
	return gradeService.fetchAll();
}
@DeleteMapping("/user/{id}")
public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable int id){
User user = userService.fetchUserById(id);
repo.delete(user);
Map<String, Boolean> response = new HashMap<>();
response.put("deleted", Boolean.TRUE);
return ResponseEntity.ok(response);
}
@DeleteMapping("/department/{id}")
public ResponseEntity<Map<String, Boolean>> deleteDepartment(@PathVariable int id){
Department department = deptService.fetchDepartmentById(id);
repo1.delete(department);
Map<String, Boolean> response = new HashMap<>();
response.put("deleted", Boolean.TRUE);
return ResponseEntity.ok(response);
}
@DeleteMapping("/salary/{id}")
public ResponseEntity<Map<String, Boolean>> deleteSalary(@PathVariable int id){
Salary salary = salaryService.fetchSalaryById(id);
repo2.delete(salary);
Map<String, Boolean> response = new HashMap<>();
response.put("deleted", Boolean.TRUE);
return ResponseEntity.ok(response);
}
@DeleteMapping("/grade1/{id}")
public ResponseEntity<Map<String, Boolean>> deleteGrade(@PathVariable int id){
Grade grade = gradeService.fetchGradeById(id);
repo3.delete(grade);
Map<String, Boolean> response = new HashMap<>();
response.put("deleted", Boolean.TRUE);
return ResponseEntity.ok(response);
}
@PostMapping("/login")
public ResponseEntity<?> loginUser( @RequestBody Login loginData) {



Login login= userService.fetchLoginByUserName(loginData.getUserName());
System.out.println("user="+login);
System.out.println("userData ID:"+loginData.getUserName());
if( login.getPassword().equals(loginData.getPassword()))
return ResponseEntity.ok(login);

return (ResponseEntity<?>) ResponseEntity.internalServerError();
}
@PutMapping("/user/{id}")
public ResponseEntity<User> updateProduct(@PathVariable int id, @RequestBody User product1) {
User user = userService.fetchUserById(id);
// .orElseThrow(() -> new ResourceNotFoundException("Product does not exist
// :"+id));
user.setId(product1.getId());
user.setEmployeeName(product1.getEmployeeName());
user.setEmployeeTitle(product1.getEmployeeTitle());
user.setDob(product1.getDob());
user.setPhoneNumber(product1.getPhoneNumber());
user.setState(product1.getState());
user.setDoj(product1.getDoj());
User updatedProduct = userService.saveUser(user);
return ResponseEntity.ok(updatedProduct);
}

@PutMapping("/salary/{id}")
public ResponseEntity<Salary> updateSalary(@PathVariable int id, @RequestBody Salary salary) {
Salary salary1 = salaryService.fetchSalaryById(id);
// .orElseThrow(() -> new ResourceNotFoundException("Product does not exist
// :"+id));
salary1.setId(salary1.getId());
salary1.setEmployeeName(salary1.getEmployeeName());
salary1.setGradeName(salary1.getGradeName());
salary1.setNetSalary(salary1.getNetSalary());
salary1.setSalaryMonth(salary1.getSalaryMonth());
salary1.setDepartmentName(salary1.getDepartmentName());
salary1.setBasicSalary(salary1.getBasicSalary());
Salary updatedSalary = salaryService.saveSalary(salary1);
return ResponseEntity.ok(updatedSalary);
}
}



		
		
	


