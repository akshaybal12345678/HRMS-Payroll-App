import { Component, OnInit } from '@angular/core';
import { Grade } from '../grade';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-emp',
  templateUrl: './grad.component.html',
  styleUrls: ['./grad.component.css']
})
export class GradComponent implements OnInit {
  grades!: Grade[];
  constructor(private _service: RegisterService) { }
  ngOnInit(): void {
     this.getGrade();
     }
     private getGrade(){
       this._service.viewGradeDet().subscribe(data =>{
         this.grades=data;
        });
      }
      deleteGrade(id: number){

        this._service.deleteGrade(id).subscribe( data => {
    
          console.log(data);
    
          this.getGrade();
    
        })}}
    