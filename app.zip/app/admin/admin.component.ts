import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { RegisterService } from '../register.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  admin:Admin =new Admin();
  users!: Admin[];
  constructor(private adminService: RegisterService) { }

  ngOnInit(): void {
  }
  adminDet(){
    console.log(this.admin);
    this.adminService.adminDet(this.admin).subscribe((data)=>{
     alert("Successfully added!")
  },error=>alert("Sorry, Admin Addition failed!"));
  }


}
