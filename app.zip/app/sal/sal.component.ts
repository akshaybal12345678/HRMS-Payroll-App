import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Salary } from '../salary'
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-sal',
  templateUrl: './sal.component.html',
  styleUrls: ['./sal.component.css']
})
export class SalComponent implements OnInit {
  salarys!: Salary[];
  constructor(private router: Router,private _service: RegisterService) { }
  ngOnInit(): void {
     this.getSalary();
     }
     private getSalary(){
       this._service.viewSalaryDet().subscribe(data =>{
         this.salarys=data;
        });
      }
     salaryDetails(id: number){
          
        this.router.navigate(['salary', id]);
   
       }
       updateSalary(id: number){

        this.router.navigate(['Sal_update_det',id])
    
      }
      deleteSalary(id: number){

        this._service.deleteSalary(id).subscribe( data => {
    
          console.log(data);
    
          this.getSalary();
    
        })}}
