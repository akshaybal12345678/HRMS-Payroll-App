import { Grade } from './grade';

describe('User', () => {
  it('should create an instance', () => {
    expect(new Grade()).toBeTruthy();
  });
});