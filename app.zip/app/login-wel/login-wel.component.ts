import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-wel',
  templateUrl: './login-wel.component.html',
  styleUrls: ['./login-wel.component.css']
})
export class LoginWelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
