import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginWelComponent } from './login-wel.component';

describe('LoginWelComponent', () => {
  let component: LoginWelComponent;
  let fixture: ComponentFixture<LoginWelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginWelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginWelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
