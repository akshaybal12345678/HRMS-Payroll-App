import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  id!: number;
  employee: Employee = new Employee();

  constructor(private _service: RegisterService,
    private route: ActivatedRoute,
    private router: Router) { } 
    ngOnInit(): void {
      this.id = this.route.snapshot.params['id']; 
      this._service.getEmployeeById(this.id).subscribe(data => {
        this.employee = data;
      }, error => console.log(error));
    } onSubmit() {
      console.log(this.employee);
    this._service.employeeDet(this.employee).subscribe(data=>{
     alert("Successfully submitted!")
     this.router.navigate(['Emp_Det'])
    },error=>alert("Sorry, submission failed!"));
  }
}
