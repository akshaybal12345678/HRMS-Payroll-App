import { LocationChangeEvent } from "@angular/common";
export class Grade {

    employeeName!:string;
    gradeName!:string;
    medicalAllowance!:number;
    basic!:number;
    travelAllowance!:number;
    providentFund!:number;
    bonus!:number;
    id!:number;
  }