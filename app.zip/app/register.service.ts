import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { Grade } from './grade';
import { Salary } from './salary';
import { Employee } from './employee';
import { Department } from './department';
import { Login } from './login';
import { Admin } from './admin';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  [x: string]: any;
 

  constructor(private httpClient: HttpClient) { }




  public registerUser(grade: Grade): Observable<Object> {

     return this.httpClient.post("http://localhost:8082/grade", grade);

  }

  public salaryPage(salary :Salary): Observable<Object> {

    return this.httpClient.post("http://localhost:8082/sal",salary);



  }
public employeeDet(employee :Employee): Observable<Object> {

    return this.httpClient.post("http://localhost:8082/user",employee);



  }
public departmentDet(department:Department): Observable<Object> {

    return this.httpClient.post("http://localhost:8082/dept",department);



  }
  public viewEmployeeDet(): Observable<Employee[]> {

    return this.httpClient.get<Employee[]>("http://localhost:8082/vuuemp12");



  }
  public viewDepartmentDet(): Observable<Department[]> {

    return this.httpClient.get<Department[]>("http://localhost:8082/vuudep34");}


    public loginUserFromRemote(login: Login): Observable<Object> {

      return this.httpClient.post("http://localhost:8082/login",login);
 
   
   
  }
  public viewSalaryDet(): Observable<Salary[]> {

    return this.httpClient.get<Salary[]>("http://localhost:8082/vuusal21");



  }
  public viewGradeDet(): Observable<Grade[]> {

    return this.httpClient.get<Grade[]>("http://localhost:8082/vuugrad21");


  }
 public deleteEmployee(id: number): Observable<Object>{

    return this.httpClient.delete("http://localhost:8082/user/" + id);

  }
  public deleteDepartment(id: number): Observable<Object>{

    return this.httpClient.delete("http://localhost:8082/department/" + id);

  }
  public adminDet(admin:Admin): Observable<Object> {

    return this.httpClient.post("http://localhost:8082/admin",admin);

 }
 getEmployeeById(id: number): Observable<Employee> {

  return this.httpClient.get<Employee>("http://localhost:8082/user/" + id);

}
getSalaryById(id: number): Observable<Salary> {

  return this.httpClient.get<Salary>("http://localhost:8082/salary/" + id);

}

public updateEmployee(id: number, employee: Employee): Observable<Object> {

  return this.httpClient.put("http://localhost:8082/user/" + id, employee);

}
public updateSalary(id: number, salary: Salary): Observable<Object> {

  return this.httpClient.put("http://localhost:8082/salary/" + id, salary);

}
public deleteSalary(id: number): Observable<Object>{

  return this.httpClient.delete("http://localhost:8082/salary/" + id);

}
public deleteGrade(id: number): Observable<Object>{

  return this.httpClient.delete("http://localhost:8082/grade1/" + id);

}


  }