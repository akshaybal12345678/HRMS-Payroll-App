import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Welcome } from '../welcome';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.css']
})
export class WelcomePageComponent implements OnInit {

  welcome:Welcome =new Welcome();

  constructor(private welcomeService: RegisterService) { }

  ngOnInit(): void {
  }

}