import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee:Employee =new Employee();

  constructor(private employeeService: RegisterService) { }

  ngOnInit(): void {
  }

  employeeDet(){
    console.log(this.employee);
    this.employeeService.employeeDet(this.employee).subscribe(data=>{
     alert("Successfully added!")
    },error=>alert("Sorry, Addition failed!"));
  }

}