import { TestBed } from '@angular/core/testing';

import { LoginWelService } from './login_wel.service';

describe('LoginService', () => {
  let service: LoginWelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginWelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});