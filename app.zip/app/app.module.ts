import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import {HttpClientModule} from '@angular/common/http';
import { WelcomePageComponent } from './welcome-page/welcome-page.component'
import { RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentDetailsComponent } from './department-details/department-details.component';
import { SalaryComponent } from './salary/salary.component';
import { LoginComponent } from './login/login.component';
import { LoginWelComponent } from './login-wel/login-wel.component';
import { DepComponent } from './dep/dep.component';
import { EmpComponent } from './emp/emp.component';
import { AdminComponent } from './admin/admin.component';
import { SalComponent } from './sal/sal.component';
import { GradComponent } from './grad/grad.component';
import { UpdateComponent } from './update/update.component';
import { SalUpdComponent } from './sal-upd/sal-upd.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    WelcomePageComponent,
    EmployeeComponent,
    DepartmentDetailsComponent,
    SalaryComponent,
    LoginComponent,
    LoginWelComponent,
    DepComponent,
    EmpComponent,
    AdminComponent,
    SalComponent,
    GradComponent,
    UpdateComponent,
    SalUpdComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'LoginWel-page', component: LoginWelComponent },
      {path: 'Login-page', component: LoginComponent },
      {path: 'Welcome-page', component: WelcomePageComponent },
      {path: 'EmployeeDet-page', component: EmployeeComponent},
      {path: 'register', component: RegisterUserComponent},
      {path: 'Department-page', component: DepartmentDetailsComponent},
      {path: 'Salary_Det', component: SalaryComponent},
      {path: 'Dep_Det', component: DepComponent},
      {path: 'Emp_Det', component: EmpComponent},
      {path: 'Admin_Det', component:  AdminComponent},
      {path: 'Sal_Det', component: SalComponent },
      {path: 'Grad_Det', component: GradComponent },
      {path: 'update_det/:id', component: UpdateComponent },
      {path: 'Sal_update_det/:id', component: SalUpdComponent}
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
