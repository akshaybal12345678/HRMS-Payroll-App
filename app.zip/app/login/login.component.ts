import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Login } from '../login';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login:Login =new Login();

  constructor(private loginService: RegisterService ,private _router:Router) { }

  ngOnInit(): void {
  }

  loginUser(){

    this.loginService.loginUserFromRemote(this.login).subscribe(data=>{

      alert("Successfully logged in")

      this._router.navigate(['Admin_Det'])

     },error=>alert("Invalid Login, please try again!"));

   

}





    
  }

