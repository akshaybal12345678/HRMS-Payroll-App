import { LocationChangeEvent } from "@angular/common";
export class Welcome {

    newEmployee!:string;
    newDepartment!:string;
    newGrade!:string;
    employeeGD!:string;

}