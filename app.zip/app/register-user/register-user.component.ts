import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Grade } from '../grade';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  grade:Grade =new Grade();

  constructor(private registerService: RegisterService) { }

  ngOnInit(): void {
  }

  gradeDetails(){
    console.log(this.grade);
    this.registerService.registerUser(this.grade).subscribe(data=>{
     alert("Successfully submitted!")
    },error=>alert("Sorry, submission failed!"));
  }

}