import { Welcome } from './welcome';

describe('Welcome', () => {
  it('should create an instance', () => {
    expect(new Welcome()).toBeTruthy();
  });
});