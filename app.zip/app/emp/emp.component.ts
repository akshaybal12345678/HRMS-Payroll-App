import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {
  
  employees!: Employee[];
  
  constructor(private router: Router,private _service: RegisterService) { }
  ngOnInit(): void {
     this.getEmployee();
     }
     private getEmployee(){
       this._service.viewEmployeeDet().subscribe(data =>{
         this.employees=data;
        });}
        userDetails(id: number){
          
         this.router.navigate(['user', id]);
    
        }
        updateEmployee(id: number){

          this.router.navigate(['update_det',id])
      
        }
        deleteEmployee(id: number){

          this._service.deleteEmployee(id).subscribe( data => {
      
            console.log(data);
      
            this.getEmployee();
      
          })
      }}
    
    


