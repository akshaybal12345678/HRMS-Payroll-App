import { LocationChangeEvent } from "@angular/common";
export class Admin {

    userName!:string;
    password!:string;
    
}