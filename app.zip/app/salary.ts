import { LocationChangeEvent } from "@angular/common";
export class Salary {
    id!:number;
    employeeName!:string;
    gradeName!:string;
    netSalary!:number;
    departmentName!:string;
    basicSalary!:number;
    salaryMonth!:string;
    medicalAllowance!:number;
 }