import { Login_wel } from './login_wel';

describe('Login_wel', () => {
  it('should create an instance', () => {
    expect(new Login_wel()).toBeTruthy();
  });
});