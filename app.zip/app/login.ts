import { LocationChangeEvent } from "@angular/common";
export class Login {

   userName!:string;
   password!:string;
   
}