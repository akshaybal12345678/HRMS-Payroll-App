import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalUpdComponent } from './sal-upd.component';

describe('SalUpdComponent', () => {
  let component: SalUpdComponent;
  let fixture: ComponentFixture<SalUpdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalUpdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalUpdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
