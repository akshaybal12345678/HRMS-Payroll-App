import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RegisterService } from '../register.service';
import { Salary } from '../salary';

@Component({
  selector: 'app-sal-upd',
  templateUrl: './sal-upd.component.html',
  styleUrls: ['./sal-upd.component.css']
})
export class SalUpdComponent implements OnInit {
  id!: number;
  salary: Salary = new Salary();

  constructor(private _service: RegisterService,
    private route: ActivatedRoute,
    private router: Router) { } 
    ngOnInit(): void {
      this.id = this.route.snapshot.params['id']; 
      this._service.getSalaryById(this.id).subscribe(data => {
        this.salary = data;
      }, error => console.log(error));
    } onSubmit() {
      console.log(this.salary);
    this._service.salaryPage(this.salary).subscribe(data=>{
     alert("Successfully submitted!")
     this.router.navigate(['Sal_Det'])
    },error=>alert("Sorry, submission failed!"));
      }
      
    }
  

