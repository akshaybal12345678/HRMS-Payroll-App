import { Component, OnInit } from '@angular/core';
import { Department } from '../department';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-dep',
  templateUrl: './dep.component.html',
  styleUrls: ['./dep.component.css']
})
export class DepComponent implements OnInit {
  
departments!: Department[];
constructor(private _service: RegisterService) { }
ngOnInit(): void {
   this.getDepartment();
   }
   private getDepartment(){
     this._service.viewDepartmentDet().subscribe(data =>{
       this.departments=data;
      });}
      deleteDepartment(id: number){

        this._service.deleteDepartment(id).subscribe( data => {
    
          console.log(data);
    
          this.getDepartment();
    
        })
    }}
  
  