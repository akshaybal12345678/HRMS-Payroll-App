import { LocationChangeEvent } from "@angular/common";
export class Employee {
    
    employeeTitle!:string;
    employeeName!:string;
    dob!:Date;
    gender!:string;
    phoneNumber!:number;
    state!:string;
    doj!:Date;
    password!:string;
    id!:number;
}