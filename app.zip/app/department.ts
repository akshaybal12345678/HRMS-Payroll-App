import { LocationChangeEvent } from "@angular/common";
export class Department {

   departmentName!:string;
    id!:number;
    
}