import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Salary } from '../salary';

@Component({
  selector: 'app-salary',
  templateUrl: './salary.component.html',
  styleUrls: ['./salary.component.css']
})
export class SalaryComponent implements OnInit {

  salary: Salary =new Salary();

  constructor(private salaryService: RegisterService) { }

  ngOnInit(): void {
  }
  salaryDet(){
    console.log(this.salary);
    this.salaryService.salaryPage(this.salary).subscribe(data=>{
     alert("Successfully submitted!")
    },error=>alert("Sorry, submission failed!"));
  }
}