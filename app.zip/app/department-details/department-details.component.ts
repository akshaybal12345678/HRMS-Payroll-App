import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Department } from '../department';

@Component({
  selector: 'app-department-details',
  templateUrl: './department-details.component.html',
  styleUrls: ['./department-details.component.css']
})
export class DepartmentDetailsComponent implements OnInit {

  department:Department =new Department();
  departments!: Department[];
  constructor(private departmentService: RegisterService) { }

  ngOnInit(): void {
    
  }

  departmentDet(){
    console.log(this.department);
    this.departmentService.departmentDet(this.department).subscribe(data=>{
     alert("Successfully added!")
  },error=>alert("Sorry, Department Addition failed!"));
  }

}